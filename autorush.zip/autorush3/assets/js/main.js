// Autók betöltése
document.addEventListener('DOMContentLoaded', function() {
    loadCars();
    setupEventListeners();
  });
  
  function loadCars() {
    fetch('api/get_cars.php')
      .then(response => response.json())
      .then(data => displayCars(data))
      .catch(error => console.error('Error:', error));
  }
  
  function displayCars(cars) {
    const container = document.getElementById('car-list');
    container.innerHTML = '';
    
    cars.forEach(car => {
      const carCard = `
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="assets/images/${car.image}" class="card-img-top" alt="${car.brand_name} ${car.model}">
            <div class="card-body">
              <h5 class="card-title">${car.brand_name} ${car.model}</h5>
              <p class="card-text">${car.year} • ${car.type}</p>
              <p class="price">${car.price_per_day.toLocaleString()} Ft/nap</p>
              <a href="car_details.php?id=${car.id}" class="btn btn-primary">Részletek</a>
            </div>
          </div>
        </div>
      `;
      container.innerHTML += carCard;
    });
  }
  
  // Foglalási dátum kalkuláció
  function setupEventListeners() {
    const pickupDate = document.getElementById('pickup_date');
    const returnDate = document.getElementById('return_date');
    
    if (pickupDate && returnDate) {
      pickupDate.addEventListener('change', calculatePrice);
      returnDate.addEventListener('change', calculatePrice);
    }
  }
  
  function calculatePrice() {
    const pickup = new Date(document.getElementById('pickup_date').value);
    const returnDate = new Date(document.getElementById('return_date').value);
    const pricePerDay = parseFloat(document.getElementById('price_per_day').value);
    
    if (pickup && returnDate && returnDate > pickup) {
      const days = Math.ceil((returnDate - pickup) / (1000 * 60 * 60 * 24));
      const total = days * pricePerDay;
      
      document.getElementById('total-price').innerHTML = `
        ${days} nap × ${pricePerDay.toLocaleString()} Ft = 
        <strong>${total.toLocaleString()} Ft</strong>
      `;
    }
  }

  // Autólista oldal funkcionalitása
document.addEventListener('DOMContentLoaded', function() {
    // Dátum választó inicializálása
    const today = new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]').forEach(input => {
        input.min = today;
    });
    
    // Szűrő űrlap eseménykezelő
    const filterForm = document.getElementById('filter-form');
    if(filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const params = new URLSearchParams(formData).toString();
            window.location.href = `cars.php?${params}`;
        });
    }
});