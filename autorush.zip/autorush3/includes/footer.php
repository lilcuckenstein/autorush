<footer class="bg-dark text-white py-4 mt-auto">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>AutoRush</h5>
                <p>Az ország vezető autóbérlő szolgáltatása</p>
            </div>
            <div class="col-md-4">
                <h5>Kapcsolat</h5>
                <p>info@autorush.hu<br>+36 1 234 5678</p>
            </div>
            <div class="col-md-4">
                <h5>Nyitvatartás</h5>
                <p>H-P: 8:00-18:00<br>Sz: 9:00-14:00</p>
            </div>
        </div>
        <div class="text-center mt-3">
            <p>&copy; <?php echo date('Y'); ?> AutoRush - Minden jog fenntartva</p>
        </div>
    </div>
</footer>