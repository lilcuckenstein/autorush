<?php
session_start();

// Hibajelzés bekapcsolása fejlesztés közben
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Adatbázis kapcsolódási adatok
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'autorush');

// Kapcsolódás az adatbázishoz
try {
    $db = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec("SET NAMES 'utf8'");
} catch(PDOException $e) {
    die("Hiba történt az adatbázis kapcsolódás közben. Kérjük, próbálja újra később.");
}

// Segédfüggvények
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data ?? '')));
}

function redirect($url) {
    header("Location: $url");
    exit();
}

// Alap URL beállítás
define('BASE_URL', 'http://localhost/autorush');
?>