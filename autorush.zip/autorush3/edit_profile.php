<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/classes/Auth.php';

if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

$auth = new Auth($db);
$user = $auth->getUser($_SESSION['user_id']);
$success = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $license = sanitizeInput($_POST['license']);

    // Simple validation
    if (!$name || !$email || !$phone || !$license) {
        $errors[] = "Minden mező kitöltése kötelező!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Érvénytelen email cím!";
    }

    if (!$errors) {
        // Update user data
        $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, phone = ?, driver_license = ? WHERE id = ?");
        $stmt->execute([$name, $email, $phone, $license, $_SESSION['user_id']]);
        $success = "Profil sikeresen frissítve!";
        // Refresh user data
        $user = $auth->getUser($_SESSION['user_id']);
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Profil szerkesztése</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Profil szerkesztése</h2>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= $e ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Név</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Telefonszám</label>
            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Jogosítványszám</label>
            <input type="text" name="license" class="form-control" value="<?= htmlspecialchars($user['driver_license']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Mentés</button>
    </form>
</div>
</body>
</html>