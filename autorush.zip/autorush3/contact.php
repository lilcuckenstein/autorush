<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $message = sanitizeInput($_POST['message']);
    
    // Itt lehetne email küldés vagy adatbázis mentés
    $_SESSION['contact_success'] = true;
    redirect('contact.php');
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapcsolat | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2 class="text-center">Kapcsolat</h2>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION['contact_success'])): ?>
                            <div class="alert alert-success">Üzenetét elküldtük! Hamarosan felvesszük Önnel a kapcsolatot.</div>
                            <?php unset($_SESSION['contact_success']); ?>
                        <?php endif; ?>
                        
                        <form method="post" action="contact.php">
                            <div class="mb-3">
                                <label for="name" class="form-label">Név</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email cím</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Üzenet</label>
                                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">Üzenet küldése</button>
                        </form>
                        
                        <div class="mt-4">
                            <h4>Elérhetőségeink</h4>
                            <p><strong>Cím:</strong> 1234 Budapest, Autó utca 1.</p>
                            <p><strong>Telefon:</strong> +36 1 234 5678</p>
                            <p><strong>Email:</strong> info@autorush.hu</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php']; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>