<?php
class CarManager {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function getFeaturedCars() {
        $stmt = $this->db->prepare("
            SELECT c.*, b.name as brand_name 
            FROM cars c 
            JOIN brands b ON c.brand_id = b.id 
            ORDER BY RAND() 
            LIMIT 3
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCars($filters = []) {
        $query = "SELECT c.*, b.name as brand_name FROM cars c JOIN brands b ON c.brand_id = b.id WHERE 1=1";
        $params = [];
        
        if(!empty($filters['type'])) {
            $query .= " AND c.type = ?";
            $params[] = $filters['type'];
        }
        
        if(!empty($filters['price'])) {
            $priceRange = explode('-', $filters['price']);
            if(count($priceRange) === 2) {
                $query .= " AND c.price_per_day BETWEEN ? AND ?";
                $params[] = $priceRange[0];
                $params[] = $priceRange[1];
            }
        }
        
        $query .= " ORDER BY c.price_per_day ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCarDetails($carId) {
        $stmt = $this->db->prepare("SELECT * FROM cars WHERE id = ?");
        $stmt->execute([$carId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function getBrands() {
        $stmt = $this->db->prepare("SELECT id, name FROM brands ORDER BY name ASC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function addCar($carData) {
        $stmt = $this->db->prepare("
            INSERT INTO cars (brand_id, model, year, type, seats, price_per_day, description, image, available)
            VALUES (:brand_id, :model, :year, :type, :seats, :price_per_day, :description, :image, :available)
        ");
        $stmt->execute([
            ':brand_id' => $carData['brand_id'],
            ':model' => $carData['model'],
            ':year' => $carData['year'],
            ':type' => $carData['type'],
            ':seats' => $carData['seats'],
            ':price_per_day' => $carData['price_per_day'],
            ':description' => $carData['description'],
            ':image' => $carData['image'],
            ':available' => $carData['available']
        ]);
    }
    public function updateCar($carId, $carData) {
        $stmt = $this->db->prepare("
            UPDATE cars
            SET brand_id = :brand_id, model = :model, year = :year, type = :type, seats = :seats,
                price_per_day = :price_per_day, description = :description, image = :image, available = :available
            WHERE id = :id
        ");
        $stmt->execute([
            ':brand_id' => $carData['brand_id'],
            ':model' => $carData['model'],
            ':year' => $carData['year'],
            ':type' => $carData['type'],
            ':seats' => $carData['seats'],
            ':price_per_day' => $carData['price_per_day'],
            ':description' => $carData['description'],
            ':image' => $carData['image'],
            ':available' => $carData['available'],
            ':id' => $carId
        ]);
    }
}
?>