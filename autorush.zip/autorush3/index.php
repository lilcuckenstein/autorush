<?php
require_once 'config.php';
require_once 'classes/CarManager.php';

$carManager = new CarManager($db);
$featuredCars = $carManager->getFeaturedCars();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoRush - Autóbérlés</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <section class="hero-section mb-5">
            <div class="hero-content text-center text-white">
                <h1 class="display-4">Fedezd fel flottánkat</h1>
                <p class="lead">Minőségi autók kedvező áron</p>
                <a href="cars.php" class="btn btn-primary btn-lg">Bérelj most</a>
            </div>
        </section>

        <h2 class="text-center mb-4">Kiemelt ajánlataink</h2>
        <div class="row">
            <?php foreach($featuredCars as $car): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="assets/images/<?php echo $car['image']; ?>" class="card-img-top" alt="<?php echo $car['brand_name'].' '.$car['model']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $car['brand_name'].' '.$car['model']; ?></h5>
                        <p class="card-text"><?php echo $car['year']; ?> • <?php echo $car['type']; ?></p>
                        <p class="price"><?php echo number_format($car['price_per_day'], 0, ',', ' '); ?> Ft/nap</p>
                        <a href="car_details.php?id=<?php echo $car['id']; ?>" class="btn btn-primary">Részletek</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>