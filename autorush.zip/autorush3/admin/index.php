<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Főoldal | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #212529;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover {
            color: white;
        }
        .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar bg-dark collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="bi bi-people me-2"></i> Felhasználók
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bookings.php">
                                <i class="bi bi-calendar-check me-2"></i> Foglalások
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cars.php">
                                <i class="bi bi-car-front me-2"></i> Járművek
                            </a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i> Kijelentkezés
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Admin Dashboard</h1>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card text-white bg-primary mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="card-title">Felhasználók</h5>
                                        <?php
                                        $stmt = $db->query("SELECT COUNT(*) FROM users");
                                        $count = $stmt->fetchColumn();
                                        ?>
                                        <h2 class="mb-0"><?php echo $count; ?></h2>
                                    </div>
                                    <i class="bi bi-people fs-1"></i>
                                </div>
                            </div>
                            <div class="card-footer">
                                <a href="users.php" class="text-white">Összes megtekintése <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="card-title">Aktív Foglalások</h5>
                                        <?php
                                        $stmt = $db->query("SELECT COUNT(*) FROM bookings WHERE status IN ('pending', 'confirmed')");
                                        $count = $stmt->fetchColumn();
                                        ?>
                                        <h2 class="mb-0"><?php echo $count; ?></h2>
                                    </div>
                                    <i class="bi bi-calendar-check fs-1"></i>
                                </div>
                            </div>
                            <div class="card-footer">
                                <a href="bookings.php" class="text-white">Összes megtekintése <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card text-white bg-warning mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="card-title">Járművek</h5>
                                        <?php
                                        $stmt = $db->query("SELECT COUNT(*) FROM cars");
                                        $count = $stmt->fetchColumn();
                                        ?>
                                        <h2 class="mb-0"><?php echo $count; ?></h2>
                                    </div>
                                    <i class="bi bi-car-front fs-1"></i>
                                </div>
                            </div>
                            <div class="card-footer">
                                <a href="cars.php" class="text-dark">Összes megtekintése <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Legújabb Foglalások</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Felhasználó</th>
                                        <th>Jármű</th>
                                        <th>Dátum</th>
                                        <th>Státusz</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $stmt = $db->query("
                                        SELECT b.id, u.name as user_name, c.model, b.start_date, b.end_date, b.status 
                                        FROM bookings b
                                        JOIN users u ON b.user_id = u.id
                                        JOIN cars c ON b.car_id = c.id
                                        ORDER BY b.created_at DESC
                                        LIMIT 5
                                    ");
                                    while($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                                    ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo $row['user_name']; ?></td>
                                        <td><?php echo $row['model']; ?></td>
                                        <td><?php echo date('Y.m.d', strtotime($row['start_date'])); ?> - <?php echo date('Y.m.d', strtotime($row['end_date'])); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                switch($row['status']) {
                                                    case 'confirmed': echo 'success'; break;
                                                    case 'pending': echo 'warning'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?php 
                                                    switch($row['status']) {
                                                        case 'confirmed': echo 'Megerősítve'; break;
                                                        case 'pending': echo 'Függőben'; break;
                                                        default: echo 'Törölve';
                                                    }
                                                ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar toggle
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('.sidebar');
            const toggleBtn = document.createElement('button');
            toggleBtn.className = 'btn btn-primary position-fixed top-1 start-1 m-3 d-md-none';
            toggleBtn.innerHTML = '<i class="bi bi-list"></i>';
            toggleBtn.onclick = function() {
                sidebar.classList.toggle('collapse');
            };
            document.body.appendChild(toggleBtn);
        });
    </script>
</body>
</html>