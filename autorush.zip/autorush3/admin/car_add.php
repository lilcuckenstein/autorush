<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../classes/CarManager.php'; // Correct path to CarManager.php

$carManager = new CarManager($db);

// Márkák listája
$brands = $carManager->getBrands();

// Új jármű hozzáadása
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $carData = [
        'brand_id' => (int)$_POST['brand_id'],
        'model' => sanitizeInput($_POST['model']),
        'year' => (int)$_POST['year'],
        'type' => sanitizeInput($_POST['type']),
        'seats' => (int)$_POST['seats'],
        'price_per_day' => (float)$_POST['price_per_day'],
        'description' => sanitizeInput($_POST['description']),
        'available' => isset($_POST['available']) ? 1 : 0
    ];
    
    // Képfeltöltés kezelése
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $uploadDir = realpath(__DIR__ . '/../../assets/images/') . '/';
        $fileName = basename($_FILES['image']['name']);
        $targetPath = $uploadDir . $fileName;
        
        if(move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            $carData['image'] = $fileName;
            
            try {
                $carManager->addCar($carData);
                $_SESSION['admin_message'] = ['type' => 'success', 'text' => 'Jármű sikeresen hozzáadva!'];
                header("Location: cars.php");
                exit;
            } catch(PDOException $e) {
                $error = "Hiba történt a mentés során: " . $e->getMessage();
            }
        } else {
            $error = "Hiba történt a kép feltöltése során!";
        }
    } else {
        $error = "Kép feltöltése kötelező!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Új Jármű Hozzáadása | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'includes/admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Új Jármű Hozzáadása</h1>
        </div>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="brand_id" class="form-label">Márka</label>
                            <select class="form-select" id="brand_id" name="brand_id" required>
                                <option value="">Válassz márkát</option>
                                <?php foreach($brands as $brand): ?>
                                    <option value="<?php echo $brand['id']; ?>"><?php echo $brand['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="model" class="form-label">Modell</label>
                            <input type="text" class="form-control" id="model" name="model" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="year" class="form-label">Évjárat</label>
                            <input type="number" class="form-control" id="year" name="year" min="2000" max="<?php echo date('Y'); ?>" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="type" class="form-label">Típus</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="SUV">SUV</option>
                                <option value="Sedan">Sedan</option>
                                <option value="Hatchback">Hatchback</option>
                                <option value="Sports">Sports</option>
                                <option value="Luxury">Luxury</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="seats" class="form-label">Ülések száma</label>
                            <input type="number" class="form-control" id="seats" name="seats" min="2" max="8" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="price_per_day" class="form-label">Ár/nap (Ft)</label>
                            <input type="number" class="form-control" id="price_per_day" name="price_per_day" min="0" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Kép</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Leírás</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="available" name="available" checked>
                        <label class="form-check-label" for="available">Elérhető</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Mentés</button>
                    <a href="cars.php" class="btn btn-outline-secondary">Mégse</a>
                </form>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>