<?php
require_once 'config.php';

if(!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: users.php");
    exit;
}

$userId = (int)$_GET['id'];

// Felhasználó adatainak lekérése
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user) {
    header("Location: users.php");
    exit;
}

// Adatok frissítése
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $license = sanitizeInput($_POST['license']);
    
    try {
        $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, phone = ?, driver_license = ? WHERE id = ?");
        $stmt->execute([$name, $email, $phone, $license, $userId]);
        
        $_SESSION['admin_message'] = ['type' => 'success', 'text' => 'Felhasználó adatai sikeresen frissítve!'];
        header("Location: users.php");
        exit;
    } catch(PDOException $e) {
        $error = "Hiba történt a frissítés során: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Felhasználó Szerkesztése | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'includes/admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Felhasználó Szerkesztése</h1>
        </div>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">Teljes név</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email cím</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Telefonszám</label>
                        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo $user['phone']; ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="license" class="form-label">Jogosítványszám</label>
                        <input type="text" class="form-control" id="license" name="license" value="<?php echo $user['driver_license']; ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Mentés</button>
                    <a href="users.php" class="btn btn-outline-secondary">Mégse</a>
                </form>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>