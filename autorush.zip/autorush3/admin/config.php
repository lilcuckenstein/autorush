<?php


require_once __DIR__ . '/../config.php'; // ne ../../config.php legyen itt, hanem csak ../

require_once __DIR__ . '/../classes/Auth.php'; // ne ../../classes/

$auth = new Auth($db);

// Admin jogosultság ellenőrzés csak akkor, ha kell:
$currentPage = basename($_SERVER['PHP_SELF']);
if ($currentPage !== 'login.php' && (!isset($_SESSION['user_id']) || !$auth->isAdmin($_SESSION['user_id']))) {
    header("Location: login.php");
    exit;
}
?>