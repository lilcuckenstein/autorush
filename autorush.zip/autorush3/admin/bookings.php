<?php
require_once 'config.php';

// Foglalás státusz módosítás
if(isset($_GET['update_status']) && is_numeric($_GET['id'])) {
    $bookingId = (int)$_GET['id'];
    $status = sanitizeInput($_GET['update_status']);
    
    try {
        $stmt = $db->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->execute([$status, $bookingId]);
        $_SESSION['admin_message'] = ['type' => 'success', 'text' => 'Foglalás státusza frissítve!'];
    } catch(PDOException $e) {
        $_SESSION['admin_message'] = ['type' => 'danger', 'text' => 'Hiba történt a frissítés során!'];
    }
    header("Location: bookings.php");
    exit;
}

// Foglalások listázása
$query = "SELECT b.*, u.name as user_name, c.model, c.brand_id, br.name as brand_name 
          FROM bookings b
          JOIN users u ON b.user_id = u.id
          JOIN cars c ON b.car_id = c.id
          JOIN brands br ON c.brand_id = br.id
          ORDER BY b.created_at DESC";
$stmt = $db->query($query);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foglalások Kezelése | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'includes/admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Foglalások Kezelése</h1>
        </div>

        <?php if(isset($_SESSION['admin_message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['admin_message']['type']; ?>">
                <?php echo $_SESSION['admin_message']['text']; ?>
            </div>
            <?php unset($_SESSION['admin_message']); ?>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Felhasználó</th>
                                <th>Jármű</th>
                                <th>Dátum</th>
                                <th>Ár</th>
                                <th>Státusz</th>
                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($bookings as $booking): ?>
                            <tr>
                                <td><?php echo $booking['id']; ?></td>
                                <td><?php echo $booking['user_name']; ?></td>
                                <td><?php echo $booking['brand_name'].' '.$booking['model']; ?></td>
                                <td><?php echo date('Y.m.d', strtotime($booking['start_date'])); ?> - <?php echo date('Y.m.d', strtotime($booking['end_date'])); ?></td>
                                <td><?php echo number_format($booking['total_price'], 0, ',', ' '); ?> Ft</td>
                                <td>
                                    <span class="badge bg-<?php 
                                        switch($booking['status']) {
                                            case 'confirmed': echo 'success'; break;
                                            case 'pending': echo 'warning'; break;
                                            case 'cancelled': echo 'secondary'; break;
                                            case 'completed': echo 'info'; break;
                                        }
                                    ?>">
                                        <?php 
                                            switch($booking['status']) {
                                                case 'confirmed': echo 'Megerősítve'; break;
                                                case 'pending': echo 'Függőben'; break;
                                                case 'cancelled': echo 'Törölve'; break;
                                                case 'completed': echo 'Teljesítve'; break;
                                            }
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                            Műveletek
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['id']; ?>&update_status=confirmed">
                                                    <i class="bi bi-check-circle text-success"></i> Megerősítés
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['id']; ?>&update_status=pending">
                                                    <i class="bi bi-hourglass text-warning"></i> Függőben
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['id']; ?>&update_status=cancelled">
                                                    <i class="bi bi-x-circle text-danger"></i> Törlés
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['id']; ?>&update_status=completed">
                                                    <i class="bi bi-check-all text-info"></i> Teljesítve
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>