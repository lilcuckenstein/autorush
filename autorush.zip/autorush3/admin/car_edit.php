<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../classes/CarManager.php';

$carManager = new CarManager($db);

// Fetch the list of brands
$brands = $carManager->getBrands();

// Get car details
if (isset($_GET['car_id']) && is_numeric($_GET['car_id'])) {
    $carId = (int)$_GET['car_id'];
    $car = $carManager->getCarDetails($carId);

    if (!$car) {
        die('A megadott jármű nem található!');
    }
} else {
    die('Érvénytelen jármű ID!');
}

// Update car details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $carData = [
        'brand_id' => (int)$_POST['brand_id'],
        'model' => sanitizeInput($_POST['model']),
        'year' => (int)$_POST['year'],
        'type' => sanitizeInput($_POST['type']),
        'seats' => (int)$_POST['seats'],
        'price_per_day' => (float)$_POST['price_per_day'],
        'description' => sanitizeInput($_POST['description']),
        'available' => isset($_POST['available']) ? 1 : 0
    ];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $uploadDir = realpath(__DIR__ . '/../../assets/images/') . '/';
        $fileName = basename($_FILES['image']['name']);
        $targetPath = $uploadDir . $fileName;
    
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            $carData['image'] = $fileName; // Save the new image name
        } else {
            $error = "Hiba történt a kép feltöltése során.";
        }
    } else {
        $carData['image'] = $car['image']; // Keep the existing image if no new image is uploaded
    }
    try {
        $carManager->updateCar($carId, $carData);
        $_SESSION['admin_message'] = ['type' => 'success', 'text' => 'Jármű sikeresen frissítve!'];
        header("Location: cars.php");
        exit;
    } catch (PDOException $e) {
        $error = "Hiba történt a frissítés során: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Járművek Kezelése | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
        <label for="brand_id" class="form-label">Márka</label>
            <select class="form-control" id="brand_id" name="brand_id" required>
                <option value="">Válassz márkát</option>
                <?php foreach ($brands as $brand): ?>
                    <option value="<?php echo $brand['id']; ?>" <?php echo $car['brand_id'] == $brand['id'] ? 'selected' : ''; ?>>
                        <?php echo $brand['name']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="model" class="form-label">Modell</label>
            <input type="text" class="form-control" id="model" name="model" value="<?php echo htmlspecialchars($car['model']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="year" class="form-label">Évjárat</label>
            <input type="number" class="form-control" id="year" name="year" value="<?php echo htmlspecialchars($car['year']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="type" class="form-label">Típus</label>
            <input type="text" class="form-control" id="type" name="type" value="<?php echo htmlspecialchars($car['type']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="seats" class="form-label">Ülések száma</label>
            <input type="number" class="form-control" id="seats" name="seats" value="<?php echo htmlspecialchars($car['seats']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="price_per_day" class="form-label">Ár naponta</label>
            <input type="text" class="form-control" id="price_per_day" name="price_per_day" value="<?php echo htmlspecialchars($car['price_per_day']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Leírás</label>
            <textarea class="form-control" id="description" name="description" required><?php echo htmlspecialchars($car['description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Kép</label>
            <input type="file" class="form-control" id="image" name="image">
            <p>Jelenlegi kép: <?php echo htmlspecialchars($car['image']); ?></p>
        </div>
        <div class="mb-3">
            <label for="available" class="form-label">Elérhető</label>
            <input type="checkbox" id="available" name="available" <?php echo $car['available'] ? 'checked' : ''; ?>>
        </div>
        <button type="submit" class="btn btn-primary">Mentés</button>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>