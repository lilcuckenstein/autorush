<?php
require_once __DIR__ . '/config.php';

if (isset($_GET['brand_id']) && is_numeric($_GET['brand_id'])) {
    $brandId = (int)$_GET['brand_id'];
    $stmt = $db->prepare("SELECT id, name FROM models WHERE brand_id = ? ORDER BY name ASC");
    $stmt->execute([$brandId]);
    $models = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($models);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'Invalid request']);
exit;