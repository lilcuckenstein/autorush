<?php
require_once 'config.php';
require_once 'classes/Auth.php';
require_once 'classes/BookingManager.php';

$auth = new Auth($db);
$bookingManager = new BookingManager($db);

if(!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

$user = $auth->getUser($_SESSION['user_id']);
$bookings = $bookingManager->getUserBookings($_SESSION['user_id']);

// Foglalás törlése
if(isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $bookingId = (int)$_GET['cancel'];
    if($bookingManager->cancelBooking($bookingId, $_SESSION['user_id'])) {
        $_SESSION['booking_cancelled'] = true;
        redirect('profile.php');
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profilom | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <?php if(isset($_SESSION['booking_success'])): ?>
            <div class="alert alert-success">Sikeres foglalás!</div>
            <?php unset($_SESSION['booking_success']); ?>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['booking_cancelled'])): ?>
            <div class="alert alert-success">Foglalás sikeresen törölve!</div>
            <?php unset($_SESSION['booking_cancelled']); ?>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h3>Profil adatok</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Név</span>
                                <span><?php echo $user['name']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Email</span>
                                <span><?php echo $user['email']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Telefon</span>
                                <span><?php echo $user['phone']; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Jogosítvány</span>
                                <span><?php echo $user['driver_license']; ?></span>
                            </li>
                        </ul>
                        <a href="edit_profile.php" class="btn btn-outline-primary mt-3 w-100">Profil szerkesztése</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3>Foglalásaim</h3>
                    </div>
                    <div class="card-body">
                        <?php if(count($bookings) > 0): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Jármű</th>
                                            <th>Dátum</th>
                                            <th>Ár</th>
                                            <th>Státusz</th>
                                            <th>Műveletek</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($bookings as $booking): ?>
                                            <tr>
                                                <td><?php echo $booking['brand_name'].' '.$booking['model']; ?></td>
                                                <td>
                                                    <?php echo date('Y.m.d', strtotime($booking['start_date'])); ?> - 
                                                    <?php echo date('Y.m.d', strtotime($booking['end_date'])); ?>
                                                </td>
                                                <td><?php echo number_format($booking['total_price'], 0, ',', ' '); ?> Ft</td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        switch($booking['status']) {
                                                            case 'confirmed': echo 'success'; break;
                                                            case 'pending': echo 'warning'; break;
                                                            case 'cancelled': echo 'secondary'; break;
                                                            case 'completed': echo 'info'; break;
                                                        }
                                                    ?>">
                                                        <?php 
                                                            switch($booking['status']) {
                                                                case 'confirmed': echo 'Megerősítve'; break;
                                                                case 'pending': echo 'Függőben'; break;
                                                                case 'cancelled': echo 'Törölve'; break;
                                                                case 'completed': echo 'Teljesítve'; break;
                                                            }
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if($booking['status'] == 'pending'): ?>
                                                        <a href="profile.php?cancel=<?php echo $booking['id']; ?>" class="btn btn-sm btn-outline-danger">Lemondás</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">Nincsenek aktív foglalásaid.</div>
                            <a href="cars.php" class="btn btn-primary">Új foglalás</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>