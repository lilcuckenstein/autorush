<?php
require_once 'config.php';
require_once 'classes/CarManager.php';

$carManager = new CarManager($db);

// Szűrők kezelése
$filters = [];
if(isset($_GET['type']) && !empty($_GET['type'])) {
    $filters['type'] = sanitizeInput($_GET['type']);
}
if(isset($_GET['price']) && !empty($_GET['price'])) {
    $filters['price'] = sanitizeInput($_GET['price']);
}

$cars = $carManager->getCars($filters);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Járműveink | AutoRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    
    <main class="container my-5">
        <h1 class="mb-4">Járműveink</h1>
        
        <!-- Szűrő űrlap -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="get" action="cars.php">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="type" class="form-label">Jármű típusa</label>
                            <select name="type" id="type" class="form-select">
                                <option value="">Összes</option>
                                <option value="SUV" <?php echo isset($_GET['type']) && $_GET['type'] == 'SUV' ? 'selected' : ''; ?>>SUV</option>
                                <option value="Sedan" <?php echo isset($_GET['type']) && $_GET['type'] == 'Sedan' ? 'selected' : ''; ?>>Sedan</option>
                                <option value="Hatchback" <?php echo isset($_GET['type']) && $_GET['type'] == 'Hatchback' ? 'selected' : ''; ?>>Hatchback</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="price" class="form-label">Ár tartomány</label>
                            <select name="price" id="price" class="form-select">
                                <option value="">Összes</option>
                                <option value="0-15000" <?php echo isset($_GET['price']) && $_GET['price'] == '0-15000' ? 'selected' : ''; ?>>15.000 Ft alatt</option>
                                <option value="15000-25000" <?php echo isset($_GET['price']) && $_GET['price'] == '15000-25000' ? 'selected' : ''; ?>>15.000 - 25.000 Ft</option>
                                <option value="25000-100000" <?php echo isset($_GET['price']) && $_GET['price'] == '25000-100000' ? 'selected' : ''; ?>>25.000 Ft felett</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Szűrés</button>
                            <?php if(isset($_GET['type']) || isset($_GET['price'])): ?>
                                <a href="cars.php" class="btn btn-outline-secondary ms-2">Összes</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Jármű lista -->
        <div class="row">
            <?php if(count($cars) > 0): ?>
                <?php foreach($cars as $car): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="assets/images/<?php echo $car['image']; ?>" class="card-img-top" alt="<?php echo $car['brand_name'].' '.$car['model']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $car['brand_name'].' '.$car['model']; ?></h5>
                                <p class="card-text"><?php echo $car['year']; ?> • <?php echo $car['type']; ?></p>
                                <p class="price"><?php echo number_format($car['price_per_day'], 0, ',', ' '); ?> Ft/nap</p>
                                <a href="car_details.php?id=<?php echo $car['id']; ?>" class="btn btn-primary">Részletek</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info">Nincs találat a megadott szűrőfeltételek alapján.</div>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>