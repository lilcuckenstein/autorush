<?php
include 'db.php';

header('Content-Type: application/json');

$stmt = $conn->prepare("SELECT * FROM cars WHERE availability = 1");
$stmt->execute();
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($cars);
