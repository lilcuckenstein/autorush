<?php 
include 'db.php';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoRush - Our Fleet</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Our Fleet -->
    <section class="fleet">
        <h2 class="section-title">Our fleet</h2>
        <div class="fleet-gallery">
            <?php
            $stmt = $conn->prepare("SELECT * FROM cars WHERE availability = 1");
            $stmt->execute();
            $cars = $stmt->fetchAll();

            foreach ($cars as $car) {
                echo '<div class="fleet-item">';
                echo '<img src="'.$car['image'].'" alt="'.$car['brand'].' '.$car['model'].'">';
                echo '<h3>'.$car['brand'].' '.$car['model'].'</h3>';
                echo '<p>Ár: $'.$car['price'].' / nap</p>';
                echo '</div>';
            }
            ?>
        </div>
    </section>
    <section class="fleet">
    <h2 class="section-title">Our fleet</h2>
    <div class="fleet-gallery" id="fleet-gallery"></div>
</section>

<script>
    fetch('api/get-cars.php')
        .then(response => response.json())
        .then(cars => {
            const gallery = document.getElementById('fleet-gallery');
            gallery.innerHTML = '';
            cars.forEach(car => {
                const item = document.createElement('div');
                item.className = 'fleet-item';
                item.innerHTML = `
                    <img src="${car.image}" alt="${car.brand} ${car.model}">
                    <h3>${car.brand} ${car.model}</h3>
                    <p>Ár: $${car.price} / nap</p>
                `;
                gallery.appendChild(item);
            });
        })
        .catch(error => console.error('Hiba:', error));
</script>
</body>
</html>
